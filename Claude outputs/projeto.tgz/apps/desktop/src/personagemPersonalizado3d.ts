import * as THREE from 'three';
import type { Aparencia } from './supabase';
import { ACESSORIOS_PIXEL, equipamentosDe, pixelDe } from './pixelCatalogo';
import { CORES_CALCA, CORES_CALCADO, CORES_ROUPA, roupaDe } from './pixelRoupas';

// The new cast uses the reference GLB's skin weights, bones and animation clips.
// Rebuild the illustrated cast around that rig; never scale bones or stride.
const IDENTIDADES = {
  leo: { pele:'#efb580', cabelo:'#914b2d', corte:'curto' },
  violeta: { pele:'#edaf82', cabelo:'#843fa0', corte:'longo' },
  neo: { pele:'#e7ad7c', cabelo:'#28588d', corte:'crista' },
  mika: { pele:'#f4ba91', cabelo:'#e7548c', corte:'bob' },
  orbit: { pele:'#e5e1ed', cabelo:'#16344e', corte:'robo' },
  davi: { pele:'#a96136', cabelo:'#292330', corte:'crespo' },
  flora: { pele:'#f0bc90', cabelo:'#42832c', corte:'longo' },
  nox: { pele:'#393044', cabelo:'#393044', corte:'sombra' },
  sol: { pele:'#edb985', cabelo:'#f1bc50', corte:'longo' },
  zuri: { pele:'#35c4c4', cabelo:'#973cae', corte:'crista' }
} as const;

export function personalizarAvatar3D(modelo:THREE.Object3D, ap:Aparencia):THREE.BufferGeometry[] {
  const id = pixelDe(ap).id, identidade = IDENTIDADES[id], roupa = roupaDe(ap);
  const geometrias:THREE.BufferGeometry[] = [];
  const bones = new Map<string,THREE.Bone>();
  const malhas:THREE.SkinnedMesh[] = [];
  modelo.traverse(o => { if ((o as THREE.Bone).isBone) bones.set(o.name,o as THREE.Bone); if ((o as THREE.SkinnedMesh).isSkinnedMesh) malhas.push(o as THREE.SkinnedMesh); });
  const pele = new THREE.Color(identidade.pele);
  const cima = new THREE.Color(CORES_ROUPA.find(c=>c.id===roupa.superior)!.cor);
  const calca = new THREE.Color(CORES_CALCA.find(c=>c.id===roupa.inferior)!.cor);
  const sapato = new THREE.Color(CORES_CALCADO.find(c=>c.id===roupa.calcado)!.cor);
  for (const mesh of malhas) {
    const geo = mesh.geometry.clone(); mesh.geometry = geo; geometrias.push(geo);
    const cores = geo.getAttribute('color'), indices = geo.getAttribute('skinIndex'), pesos = geo.getAttribute('skinWeight'), posicoes=geo.getAttribute('position');
    const remover = new Set<number>();
    for (let i=0;i<cores.count;i++) {
      const pesosVertice=[pesos.getX(i),pesos.getY(i),pesos.getZ(i),pesos.getW(i)];
      const dominante=pesosVertice.indexOf(Math.max(...pesosVertice));
      const osso=mesh.skeleton.bones[[indices.getX(i),indices.getY(i),indices.getZ(i),indices.getW(i)][dominante]].name;
      const r=cores.getX(i),g=cores.getY(i);
      const cabeca=/^(Head|Eye|Mouth)/.test(osso);
      // The old head, hoodie strings, badge and cuffs belong to the legacy cast.
      const tronco=/^(Chest|Spine|Hips)$/.test(osso);
      const detalheTronco=tronco && !(Math.abs(r-.5089)<.001 || Math.abs(r-.3372)<.001 || (osso==='Hips'&&r<.12) || (osso==='Chest'&&Math.abs(r-.5841)<.001));
      const punho=/^Forearm/.test(osso)&&Math.abs(r-.3419)<.001;
      const membroRobo=id==='orbit'&&/^(Arm|Forearm|Thigh|Shin)/.test(osso);
      if (cabeca || detalheTronco || punho || membroRobo) {
        remover.add(i);
      }
      let cor:THREE.Color|undefined, sombra=1;
      if (/^Foot/.test(osso)) { cor=id==='orbit'&&roupa.calcado==='cinza'?new THREE.Color('#ddd9e5'):sapato; sombra=r>.65?1.12:.8; }
      else if (/^(Thigh|Shin)/.test(osso)||(osso==='Hips'&&r<.12)) { cor=id==='orbit'&&roupa.inferior==='grafite'?pele:calca; sombra=r<.05?.8:1; }
      else if (/^Hand/.test(osso)&&id==='orbit') {cor=new THREE.Color('#252839');}
      else if (roupa.modelo==='basica'&&(/^Forearm/.test(osso)||(/^Arm/.test(osso)&&posicoes.getY(i)<.965))) {cor=pele;}
      else if (/^(Hand|Neck)/.test(osso)||(osso==='Head'&&r>.3)||(osso==='Chest'&&r>.55&&g>.2&&g<.3)) { cor=pele; sombra=Math.min(1.12,Math.max(.63,r/.584)); }
      else if (!cabeca) { cor=cima; sombra=r<.4?.85:1; }
      if (cor) cores.setXYZ(i,Math.min(1,cor.r*sombra),Math.min(1,cor.g*sombra),Math.min(1,cor.b*sombra));
    }
    // Preserve triangles crossing limb joints, but recolor even their removed-side
    // vertices so the source model's brown sleeves cannot leak into the shoulders.
    const antigos=geo.index;
    const novos:number[]=[];
    for(let i=0;i<(antigos?.count??cores.count);i+=3) {
      const tri=[0,1,2].map(k=>antigos?antigos.getX(i+k):i+k);
      if(!tri.every(v=>remover.has(v))) novos.push(...tri);
    }
    geo.setIndex(novos); cores.needsUpdate=true;
  }
  const materiais=new Map<string,THREE.MeshStandardMaterial>();
  function material(cor:string,metal=false) {
    const chave=cor+metal;
    if(!materiais.has(chave)) materiais.set(chave,new THREE.MeshStandardMaterial({color:cor,roughness:metal?.35:.75,metalness:metal?.4:0}));
    return materiais.get(chave)!;
  }
  function peca(parent:THREE.Object3D,geo:THREE.BufferGeometry,cor:string,x:number,y:number,z:number,metal=false) {
    geometrias.push(geo);const mesh=new THREE.Mesh(geo,material(cor,metal));mesh.position.set(x,y,z);parent.add(mesh);return mesh;
  }
  function bola(p:THREE.Object3D,c:string,x:number,y:number,z:number,sx:number,sy:number,sz:number) {
    const m=peca(p,new THREE.SphereGeometry(1,16,12),c,x,y,z);m.scale.set(sx,sy,sz);return m;
  }
  function caixa(p:THREE.Object3D,c:string,x:number,y:number,z:number,sx:number,sy:number,sz:number) {return peca(p,new THREE.BoxGeometry(sx,sy,sz),c,x,y,z);}
  function aro(p:THREE.Object3D,c:string,x:number,y:number,z:number,r:number,t=.018) {return peca(p,new THREE.TorusGeometry(r,t,8,24),c,x,y,z);}
  function prender(osso:string,nome:string) {
    const bone=bones.get(osso);if(!bone) throw Error(`Osso ausente: ${osso}`);
    const group=new THREE.Group();group.name=nome;
    // Shapes are authored upright in the bind pose, including hand accessories.
    group.quaternion.copy(bone.getWorldQuaternion(new THREE.Quaternion()).invert());bone.add(group);return group;
  }
  function curva(p:THREE.Object3D,c:string,pontos:number[][],raio=.012,nome='') {
    const mesh=peca(p,new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pontos.map(v=>new THREE.Vector3(...v))),20,raio,6,false),c,0,0,0);
    mesh.name=nome;return mesh;
  }
  function mecha(p:THREE.Object3D,c:string,pontos:number[][],largura:number) {
    // A tapered lock follows a curved centreline, rather than a row of balls.
    const caminho=new THREE.CatmullRomCurve3(pontos.map(v=>new THREE.Vector3(...v)));
    const geo=new THREE.TubeGeometry(caminho,16,largura,8,false),pos=geo.getAttribute('position');
    for(let j=0;j<=16;j++) {
      const t=j/16,centro=caminho.getPointAt(t),fator=.015+.985*Math.pow(Math.sin(Math.PI*(.13+t*.87)),.6);
      for(let k=0;k<=8;k++) {
        const i=j*9+k,v=new THREE.Vector3().fromBufferAttribute(pos,i).sub(centro).multiplyScalar(fator).add(centro);
        pos.setXYZ(i,v.x,v.y,v.z);
      }
    }
    geo.computeVertexNormals();return peca(p,geo,c,0,0,0);
  }
  const head=prender('Head',`identidade-${id}`),hair=identidade.cabelo;
  if (identidade.corte==='robo'||identidade.corte==='sombra') {
    const robo=id==='orbit',luz=robo?'#35eeeb':'#ffc323';
    bola(head,identidade.pele,0,.255,0,.355,.33,.29).name='cabeca-base';
    if(robo) {
      bola(head,'#a4a1b5',0,.24,.225,.295,.249,.086);
      bola(head,'#151d2f',0,.24,.26,.27,.219,.068).name='visor-orbit';
      curva(head,'#a4a1b5',[[-.14,.535,.13],[-.09,.484,.231],[0,.47,.26],[.09,.484,.231],[.14,.535,.13]],.009);
      for(const x of [-.349,.349]) bola(head,'#b5afc2',x,.25,0,.025,.12,.11);
    }
    for(const x of [-.125,.125]) {
      const olho=curva(head,luz,[[x-.063,.257,robo?.317:.264],[x-.035,.297,robo?.329:.277],[x,.308,robo?.336:.282],[x+.035,.297,robo?.329:.277],[x+.063,.257,robo?.317:.264]],.016,'olho-sorridente');
      (olho.material as THREE.MeshStandardMaterial).emissive.set(luz);
      (olho.material as THREE.MeshStandardMaterial).emissiveIntensity=.6;
    }
    curva(head,robo?luz:'#211d2b',[[-.06,.16,robo?.324:.28],[0,.135,robo?.332:.292],[.06,.16,robo?.324:.28]],.01,'sorriso');
  } else {
    bola(head,identidade.pele,0,.24,0,.32,.305,.27).name='cabeca-base';
    for(const lado of [-1,1]) {
      if(id==='flora') {
        const orelha=mecha(head,identidade.pele,[[lado*.275,.22,0],[lado*.36,.26,0],[lado*.455,.31,-.015]],.083);
        orelha.name='orelha-elfica';
      } else bola(head,identidade.pele,lado*.315,.22,0,.06,.079,.055);
      bola(head,id==='zuri'?'#24958e':'#d88b68',lado*.323,.221,.04,.027,.043,.018);
      const x=lado*.122,iris=id==='flora'?'#426238':id==='zuri'?'#145464':'#493728';
      bola(head,'#fff6e9',x,.263,.239,.084,.102,.044).name='olho-branco';
      bola(head,iris,x,.26,.278,.052,.075,.022);
      bola(head,'#141923',x,.263,.294,.032,.057,.013);
      bola(head,'#ffffff',x-.018,.296,.305,.017,.022,.008);
      bola(head,'#ffffff',x+.018,.232,.303,.007,.008,.006);
      curva(head,hair,[[x-.06,.378,.227],[x,.393,.249],[x+.06,.38,.227]],.013,'sobrancelha');
      if(['violeta','mika','flora','sol'].includes(id)) curva(head,'#392a32',[[x-lado*.07,.292,.256],[x+lado*.04,.346,.256],[x+lado*.086,.339,.236]],.01);
    }
    bola(head,identidade.pele,0,.178,.264,.033,.037,.032);
    curva(head,id==='zuri'?'#196e78':'#a65141',[[-.066,.095,.245],[0,.078,.26],[.066,.095,.245]],.01,'sorriso');
    if(id==='davi') curva(head,'#372a2b',[[-.16,.047,.175],[-.08,-.004,.19],[0,-.025,.2],[.08,-.004,.19],[.16,.047,.175]],.013);
    // Scalp is open at the forehead; locks define each silhouette from the atlas.
    peca(head,new THREE.SphereGeometry(.335,24,14,0,Math.PI*2,0,Math.PI*.52),hair,0,.32,-.035).scale.set(1,.78,.91);
    const brilho=new THREE.Color(hair).lerp(new THREE.Color('#ffffff'),.045).getStyle();
    if(identidade.corte==='longo'||identidade.corte==='bob') {
      const longo=identidade.corte==='longo';
      bola(head,hair,0,longo?.05:.23,-.18,.3,longo?.45:.25,.14);
      for(const lado of [-1,1]) for(let n=0;n<3;n++) {
        const x=lado*(.27+n*.035),z=.045-n*.115;
        const pontos=longo
          ? [[lado*.075,.555,-.035],[x,.43,z],[x+lado*.055,.25,z],[x,.10,z+.025],[x+lado*.095,-.05,z],[x+lado*.035,-.18,z+.025],[x+lado*.09,-.31,z],[x,-.46,z-.025]]
          : [[lado*.075,.555,-.035],[x,.43,z],[x+lado*.04,.25,z],[x+lado*.035,.10,z+.025],[x,.045,z-.025]];
        mecha(head,n===0?brilho:hair,pontos,longo?.105:.09);
      }
      if(id==='sol'||id==='violeta') {
        for(const lado of [-1,1]) for(let n=0;n<2;n++) mecha(head,n?brilho:hair,[[lado*.025,.56,.04],[lado*.13,.52,.19],[lado*(.24+n*.025),.39,.23],[lado*.30,.26,.12]],.08);
      } else for(let n=0;n<3;n++) mecha(head,n===1?brilho:hair,[[.08+n*.045,.57,.04],[-.035+n*.03,.50,.22],[-.19+n*.04,.37,.242],[-.28+n*.025,.28,.12]],.074);
    } else if(identidade.corte==='crespo') {
      for(let row=0;row<3;row++) for(let n=0;n<12;n++) {
        const a=n*Math.PI/6+row*.22,raio=.29-row*.065;
        bola(head,n%4===0?brilho:hair,Math.cos(a)*raio,.395+row*.072,Math.sin(a)*raio-.02,.065,.067,.065);
      }
      bola(head,hair,0,.57,-.02,.12,.065,.12);
    } else {
      const zuri=id==='zuri';
      for(let n=0;n<6;n++) {
        const x=.22-n*.075;
        mecha(head,n%2?hair:brilho,[[x,.45,-.12],[x+.055,.55,.025],[x-.055,.52,.2],[x-.14,.365+(n%2)*.045,.255]],.115);
      }
      for(let n=0;n<4;n++) mecha(head,hair,[[.16-n*.11,.44,-.16],[.2-n*.13,.59,-.11],[.12-n*.15,.64,-.09]],.095);
      if(zuri) for(let n=0;n<3;n++) curva(head,'#215b6c',[[.301,.29+n*.033,-.03],[.32,.30+n*.033,.045],[.29,.32+n*.033,.12]],.011);
    }
  }
  if(id==='orbit') {
    const branco='#e5e1ed',junta='#252839';
    // Each plate follows its own limb, leaving the elbow/knee articulation exposed.
    function segmento(inicio:string,fim:string,cor:string,largura:number,profundidade:number) {
      const g=prender(inicio,`armadura-${inicio}`),a=bones.get(inicio)!.getWorldPosition(new THREE.Vector3()),b=bones.get(fim)!.getWorldPosition(new THREE.Vector3());
      const delta=b.sub(a),centro=delta.clone().multiplyScalar(.52);
      const geo=new THREE.CylinderGeometry(largura*.8,largura,delta.length()*.76,10,1);
      // Broad armour shells, instead of cloth sleeves or spherical limbs.
      const m=peca(g,geo,cor,centro.x,centro.y,centro.z,true);m.scale.z=profundidade/largura;
      m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),delta.clone().normalize());
      bola(g,junta,0,0,0,largura*.73,largura*.73,profundidade*.8);
    }
    for(const lado of ['L','R']) {
      segmento(`Arm${lado}`,`Forearm${lado}`,roupa.modelo==='basica'?branco:CORES_ROUPA.find(c=>c.id===roupa.superior)!.cor,.089,.087);
      segmento(`Forearm${lado}`,`Hand${lado}`,branco,.077,.073);
      const perna=roupa.inferior==='grafite'?branco:CORES_CALCA.find(c=>c.id===roupa.inferior)!.cor;
      segmento(`Thigh${lado}`,`Shin${lado}`,perna,.098,.103);
      segmento(`Shin${lado}`,`Foot${lado}`,perna,.087,.086);
    }
  }
  const torso=prender('Chest',`roupa-${roupa.modelo}`);
  const camisa=CORES_ROUPA.find(c=>c.id===roupa.superior)!.cor;
  function painel(cor:string,pontos:number[][],z=.206) {
    const forma=new THREE.Shape(pontos.map(([x,y])=>new THREE.Vector2(x,y)));
    return peca(torso,new THREE.ExtrudeGeometry(forma,{depth:.009,bevelEnabled:false}),cor,0,0,z);
  }
  if(roupa.modelo==='casual'||roupa.modelo==='executiva') {
    if(roupa.modelo==='executiva') {
      painel('#eee8dc',[[-.07,.14],[.07,.14],[0,-.05]]);
      const lapela=new THREE.Color(camisa).lerp(new THREE.Color('#ffffff'),.12).getStyle();
      for(const lado of [-1,1]) painel(lapela,[[lado*.085,.14],[lado*.125,.07],[lado*.04,-.015],[0,-.09],[lado*.055,.06]],.218);
      for(const y of [-.14,-.2]) bola(torso,'#d7c0a0',0,y,.226,.011,.011,.006);
      for(const x of [-.13,.13]) caixa(torso,'#252a3b',x,-.17,.213,.065,.012,.009);
    } else {
      painel('#e7e2d7',[[-.048,.135],[.048,.135],[.065,-.235],[-.065,-.235]]);
      for(const x of [-.13,.13]) caixa(torso,'#8990a0',x,-.04,.218,.052,.012,.009);
    }
  }
  if(roupa.modelo==='futurista') {
    for(const lado of [-1,1]) curva(torso,'#4ee1e5',[[lado*.145,.07,.211],[lado*.145,-.10,.211],[lado*.075,-.10,.211]],.008);
    caixa(torso,'#4ee1e5',0,.055,.211,.014,.15,.012);
    caixa(torso,'#252a3b',0,-.24,.184,.34,.045,.035);
    caixa(torso,'#4ee1e5',0,-.24,.207,.055,.028,.012);
  }

  for(const [slot,acessorio] of Object.entries(equipamentosDe(ap))) {
    const item=ACESSORIOS_PIXEL.find(a=>a.id===acessorio)!;
    const bone=slot==='mao'?'HandR':slot==='pulso'?'HandL':slot==='bolsa'?'Spine':slot==='pescoco'?'Chest':slot==='detalhe'&&['broche-lua','drone'].includes(item.id)?'Chest':'Head';
    const g=prender(bone,`acessorio-${item.id}`);
    const nome=item.id;
    const c=/ciano|tech|hologra|neon|ar$/.test(nome)?'#36dce0':/roxa|cristal|lua/.test(nome)?'#9e68d9':/folha|floral/.test(nome)?'#459b64':/palha|flor$|creme|social/.test(nome)?'#e9c979':/preto|sol|capuz|utilitaria/.test(nome)?'#252c40':'#e56688';
    g.userData.slot=slot;
    if(slot==='cabeca') {
      if(/fone|headset|vr/.test(nome)) {
        const band=aro(g,'#24354a',0,.29,0,.35,.035);band.rotation.y=Math.PI/2;
        for(const x of [-.34,.34]) caixa(g,c,x,.25,0,.09,.18,.15);
        if(nome.startsWith('vr')) {caixa(g,c,0,.26,.29,.48,.19,.09);caixa(g,'#152235',0,.26,.342,.4,.12,.025);}
        if(/gato|coelho/.test(nome)) for(const x of [-.22,.22]) peca(g,new THREE.ConeGeometry(.095,/coelho/.test(nome)?.32:.18,4),c,x,.64,0);
        if(nome==='headset') caixa(g,'#24354a',-.24,.13,.25,.025,.025,.22);
      } else if(nome==='capuz') {
        peca(g,new THREE.SphereGeometry(.38,20,12,Math.PI*.5,Math.PI,0,Math.PI),c,0,.29,0);
        for(const x of [-.3,.3]) bola(g,c,x,.2,.035,.09,.29,.18);
      } else if(/coroa|flores|floral|tiara|orelhas/.test(nome)) {
        const ring=aro(g,c,0,.57,0,.3,.03);ring.rotation.x=Math.PI/2;
        for(let n=0;n<7;n++) {
          const a=n*Math.PI/3.5,x=Math.cos(a)*.29,z=Math.sin(a)*.29;
          if(/flor/.test(nome)) {bola(g,n%2?'#f2b655':'#ef849a',x,.59,z,.06,.04,.055);bola(g,'#fff0a4',x,.625,z,.023,.02,.023);}
          else peca(g,new THREE.ConeGeometry(.045,.12,4),c,x,.65,z);
        }
        if(nome==='orelhas-raposa') for(const x of [-.22,.22]) peca(g,new THREE.ConeGeometry(.12,.25,4),'#bc723d',x,.69,0);
      } else {
        const brim=peca(g,new THREE.CylinderGeometry(.42,.42,.035,24),c,0,.55,0);if(nome==='bone') {brim.scale.set(.8,1,1);brim.position.z=.07;}
        const altura=nome==='gorro'?.24:.17;
        peca(g,new THREE.CylinderGeometry(nome==='bucket'?.24:.26,.3,altura,20),c,0,.55+altura/2,-.025);
        if(nome==='gorro') bola(g,c,0,.83,-.025,.065,.065,.065);
        if(nome==='chapeu-flor') bola(g,'#eb6489',.29,.64,.12,.07,.07,.045);
      }
    } else if(slot==='rosto') {
      for(const x of [-.115,.115]) {
        aro(g,c,x,.265,.3,.085,.014);
        if(/sol|preto|ar$/.test(nome)) bola(g,'#20374c',x,.265,.303,.075,.06,.012);
        if(/coracao/.test(nome)) for(const dx of [-.028,.028]) bola(g,c,x+dx,.3,.303,.04,.035,.015);
      }
      caixa(g,c,0,.28,.3,.07,.018,.018);
      for(const x of [-.21,.21]) caixa(g,c,x,.28,.17,.014,.018,.26);
    } else if(slot==='bolsa') {
      const mochila=nome.startsWith('mochila');
      const x=mochila?0:.25,z=mochila?-.21:.035;
      caixa(g,c,x,-.04,z,mochila?.3:.19,.29,.13);
      caixa(g,'#d7dfe7',x,-.02,z+(mochila?-.075:.075),.08,.025,.015);
      if(mochila) for(const lado of [-1,1]) caixa(g,c,lado*.16,.13,-.14,.045,.29,.04);
      else {const alca=aro(g,c,x,.17,z,.08,.014);alca.scale.y=1.3;}
    } else if(slot==='pescoco') {
      if(/gravata|cracha/.test(nome)) {
        caixa(g,c,0,-.035,.181,.05,.23,.025);
        if(nome==='cracha') {caixa(g,'#e4eef5',0,-.14,.2,.12,.1,.025);caixa(g,c,0,-.12,.215,.08,.02,.009);}
      } else if(/borboleta|laco/.test(nome)) for(const lado of [-1,1]) bola(g,c,lado*.055,.12,.17,.06,.035,.03);
      else if(nome==='fone-pescoco') {for(const x of [-.14,.14]) caixa(g,c,x,.1,.1,.08,.1,.08);aro(g,'#283348',0,.14,0,.17,.02).rotation.x=Math.PI/2;}
      else {aro(g,c,0,.15,0,.135,.025).rotation.x=Math.PI/2;bola(g,c,0,.06,.17,.045,.065,.025);}
    } else if(slot==='pulso') {
      const pulseira=aro(g,c,0,.025,0,.058,.015);pulseira.rotation.x=Math.PI/2;
      if(nome==='relogio') caixa(g,'#172739',0,.025,.055,.075,.06,.025);
    } else if(slot==='mao') {
      if(nome==='copo') {
        peca(g,new THREE.CylinderGeometry(.065,.048,.16,16),c,0,-.01,.07);
        peca(g,new THREE.CylinderGeometry(.07,.07,.018,16),'#f0e9da',0,.075,.07);
      } else if(nome==='caneta') {const m=peca(g,new THREE.CylinderGeometry(.012,.012,.19,8),c,0,0,.06);m.rotation.z=.4;}
      else if(nome==='camera') {caixa(g,c,0,0,.07,.17,.11,.09);const lente=peca(g,new THREE.CylinderGeometry(.045,.045,.06,16),'#152638',0,0,.145);lente.rotation.x=Math.PI/2;}
      else if(nome==='controle') {bola(g,c,0,0,.07,.12,.05,.065);for(const x of [-.065,.065]) bola(g,'#233147',x,.03,.1,.023,.015,.02);}
      else {caixa(g,c,0,0,.075,.16,.22,.025);caixa(g,nome==='caderno'?'#f4e9d4':'#183a51',0,0,.091,.125,.17,.012);}
    } else {
      if(nome==='drone') {
        caixa(g,c,.6,.42,0,.18,.07,.14);
        for(const x of [.48,.72]) for(const z of [-.09,.09]) {const rotor=aro(g,'#d4e7ed',x,.46,z,.065,.009);rotor.rotation.x=Math.PI/2;}
      } else if(nome==='broche-lua') aro(g,c,-.12,0,.18,.035,.012);
      else if(nome==='argola'||nome==='ear-cuff') aro(g,c,.32,.12,.04,.045,.012);
      else {const presilha=caixa(g,c,.24,.4,.21,.12,.035,.035);presilha.rotation.z=-.5;}
    }
  }
  return geometrias;
}
